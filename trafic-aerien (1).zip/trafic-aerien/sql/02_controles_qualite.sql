-- =====================================================================
-- 02 - Contrôles de qualité sur les tables brutes (brut_*)
-- Les tables brut_* sont envoyées depuis Python (notebook 01, Mission 2 - étape 3)
-- =====================================================================

-- a) Nomenclature des codes (regex)
SELECT 'faa (airports)' AS colonne, COUNT(*) AS invalides FROM brut_airports WHERE faa !~ '^[A-Z0-9]{3}$'
UNION ALL SELECT 'origin (flights)',   COUNT(*) FROM brut_flights  WHERE origin  !~ '^[A-Z]{3}$'
UNION ALL SELECT 'dest (flights)',     COUNT(*) FROM brut_flights  WHERE dest    !~ '^[A-Z]{3}$'
UNION ALL SELECT 'origin (weather)',   COUNT(*) FROM brut_weather  WHERE origin  !~ '^[A-Z]{3}$'
UNION ALL SELECT 'carrier (airlines)', COUNT(*) FROM brut_airlines WHERE carrier !~ '^[A-Z0-9]{2}$'
UNION ALL SELECT 'carrier (flights)',  COUNT(*) FROM brut_flights  WHERE carrier !~ '^[A-Z0-9]{2}$'
UNION ALL SELECT 'tailnum (planes)',   COUNT(*) FROM brut_planes   WHERE tailnum !~ '^N[A-Z0-9]{1,5}$'
UNION ALL SELECT 'tailnum (flights)',  COUNT(*) FROM brut_flights  WHERE tailnum !~ '^N[A-Z0-9]{1,5}$';
-- Résultat : tout à 0 sauf tailnum (flights) = 3 → 'D942DN'

SELECT tailnum, COUNT(*) AS nb_vols FROM brut_flights
WHERE tailnum !~ '^N[A-Z0-9]{1,5}$' GROUP BY tailnum;

-- b) Clés primaires simples : total = distincts ?
SELECT 'airports.faa' AS cle, COUNT(*) AS total, COUNT(DISTINCT faa) AS distincts, COUNT(*) - COUNT(faa) AS vides FROM brut_airports
UNION ALL SELECT 'airlines.carrier', COUNT(*), COUNT(DISTINCT carrier), COUNT(*) - COUNT(carrier) FROM brut_airlines
UNION ALL SELECT 'planes.tailnum',   COUNT(*), COUNT(DISTINCT tailnum), COUNT(*) - COUNT(tailnum) FROM brut_planes
UNION ALL SELECT 'flights.flight',   COUNT(*), COUNT(DISTINCT flight),  COUNT(*) - COUNT(flight)  FROM brut_flights;
-- Résultat : faa, carrier, tailnum = PK valides ; flight seul n'est PAS une PK (3 652 valeurs pour 252 704 vols)

-- c) Clés primaires composites
SELECT 'weather (year, month, day, hour, origin)' AS cle, COUNT(*) AS nb_doublons
FROM (SELECT year, month, day, hour, origin FROM brut_weather
      GROUP BY year, month, day, hour, origin HAVING COUNT(*) > 1) w
UNION ALL
SELECT 'flights (year, month, day, hour, carrier, flight)', COUNT(*)
FROM (SELECT year, month, day, hour, carrier, flight FROM brut_flights
      GROUP BY year, month, day, hour, carrier, flight HAVING COUNT(*) > 1) f;
-- Résultat : flights = 0 doublon (PK valide) ; weather = 3 doublons (changement d'heure du 3/11 à 1 h)

-- d) Clés étrangères
SELECT 'dest absents de airports' AS probleme, COUNT(DISTINCT dest) AS nb
FROM brut_flights WHERE dest NOT IN (SELECT faa FROM brut_airports)
UNION ALL SELECT 'origin absents de airports', COUNT(DISTINCT origin)
FROM brut_flights WHERE origin NOT IN (SELECT faa FROM brut_airports)
UNION ALL SELECT 'carrier absents de airlines', COUNT(DISTINCT carrier)
FROM brut_flights WHERE carrier NOT IN (SELECT carrier FROM brut_airlines)
UNION ALL SELECT 'tailnum absents de planes', COUNT(DISTINCT tailnum)
FROM brut_flights WHERE tailnum NOT IN (SELECT tailnum FROM brut_planes)
UNION ALL SELECT 'weather.origin absents de airports', COUNT(DISTINCT origin)
FROM brut_weather WHERE origin NOT IN (SELECT faa FROM brut_airports);
-- Résultat : 4 aéroports (BQN, PSE, SJU, STT) et 716 avions manquants

-- Pourquoi autant d'avions manquants ? (AA et MQ déclarent des numéros de flotte)
SELECT carrier, COUNT(DISTINCT tailnum) AS avions_inconnus
FROM brut_flights
WHERE tailnum NOT IN (SELECT tailnum FROM brut_planes)
GROUP BY carrier ORDER BY avions_inconnus DESC;

-- e) Valeur manquante mal codée
SELECT faa, name, tzone FROM brut_airports WHERE tzone = '\N';
