-- =====================================================================
-- 05 - Gestion des privilèges (principe du moindre privilège)
-- Remplacer A_REMPLACER par de vrais mots de passe avant exécution
-- =====================================================================

-- 1. Deux groupes (rôles sans connexion)
CREATE ROLE groupe_lecture NOLOGIN;
CREATE ROLE groupe_ecriture NOLOGIN;

-- 2. Droits du groupe LECTURE : se connecter, voir les tables, lire
GRANT USAGE ON SCHEMA public TO groupe_lecture;
GRANT SELECT ON airlines, airports, planes, weather, flights TO groupe_lecture;

-- 3. Droits du groupe ÉCRITURE : tout ce que fait la lecture + ajouter / modifier / supprimer
GRANT groupe_lecture TO groupe_ecriture;
GRANT INSERT, UPDATE, DELETE ON airlines, airports, planes, weather, flights TO groupe_ecriture;
GRANT USAGE ON SEQUENCE flights_id_seq TO groupe_ecriture;

-- 4. Row Level Security : autoriser explicitement chaque groupe
CREATE POLICY lecture_airlines ON airlines FOR SELECT TO groupe_lecture USING (true);
CREATE POLICY lecture_airports ON airports FOR SELECT TO groupe_lecture USING (true);
CREATE POLICY lecture_planes   ON planes   FOR SELECT TO groupe_lecture USING (true);
CREATE POLICY lecture_weather  ON weather  FOR SELECT TO groupe_lecture USING (true);
CREATE POLICY lecture_flights  ON flights  FOR SELECT TO groupe_lecture USING (true);

CREATE POLICY ecriture_airlines ON airlines FOR ALL TO groupe_ecriture USING (true) WITH CHECK (true);
CREATE POLICY ecriture_airports ON airports FOR ALL TO groupe_ecriture USING (true) WITH CHECK (true);
CREATE POLICY ecriture_planes   ON planes   FOR ALL TO groupe_ecriture USING (true) WITH CHECK (true);
CREATE POLICY ecriture_weather  ON weather  FOR ALL TO groupe_ecriture USING (true) WITH CHECK (true);
CREATE POLICY ecriture_flights  ON flights  FOR ALL TO groupe_ecriture USING (true) WITH CHECK (true);

-- 5. Les membres du groupe (un compte par personne)
CREATE ROLE analyste1 LOGIN PASSWORD 'A_REMPLACER';
CREATE ROLE dev1      LOGIN PASSWORD 'A_REMPLACER';
GRANT groupe_lecture  TO analyste1;
GRANT groupe_ecriture TO dev1;

-- 6. Vérification : tableau des droits de chaque compte
SELECT r.compte, t.table_,
       has_table_privilege(r.compte, t.table_, 'SELECT') AS lecture,
       has_table_privilege(r.compte, t.table_, 'INSERT') AS ajout,
       has_table_privilege(r.compte, t.table_, 'UPDATE') AS modification,
       has_table_privilege(r.compte, t.table_, 'DELETE') AS suppression
FROM (VALUES ('analyste1'), ('dev1')) AS r(compte),
     (VALUES ('airlines'), ('airports'), ('planes'), ('weather'), ('flights')) AS t(table_)
ORDER BY r.compte, t.table_;
