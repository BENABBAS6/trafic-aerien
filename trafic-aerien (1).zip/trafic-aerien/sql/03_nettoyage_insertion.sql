-- =====================================================================
-- 03 - Nettoyage et insertion dans les tables finales
-- =====================================================================

-- 1. Compagnies
INSERT INTO airlines (carrier, name)
SELECT carrier, name FROM brut_airlines;

-- 2. Aéroports : "\N" → NULL, puis ajout des 4 aéroports manquants
INSERT INTO airports (faa, name, lat, lon, alt, tz, dst, tzone)
SELECT faa, name, lat, lon, alt, tz, dst, NULLIF(tzone, '\N') FROM brut_airports;

INSERT INTO airports (faa, name) VALUES
  ('BQN', 'Rafael Hernandez Airport'),
  ('PSE', 'Mercedita Airport'),
  ('SJU', 'San Juan Airport'),
  ('STT', 'Cyril E. King Airport');

-- 3. Avions + avions inconnus (immatriculation seule ; D942DN invalide est exclu)
INSERT INTO planes (tailnum, year, type, manufacturer, model, engines, seats, speed, engine)
SELECT tailnum, year, type, manufacturer, model, engines, seats, speed, engine FROM brut_planes;

INSERT INTO planes (tailnum)
SELECT DISTINCT tailnum FROM brut_flights
WHERE tailnum ~ '^N[A-Z0-9]{1,5}$'
  AND tailnum NOT IN (SELECT tailnum FROM planes);

-- 4. Météo : une seule ligne par heure et par aéroport (supprime les 3 doublons)
INSERT INTO weather
SELECT DISTINCT ON (year, month, day, hour, origin)
       origin, year, month, day, hour, temp, dewp, humid, wind_dir, wind_speed,
       wind_gust, precip, pressure, visib, time_hour::timestamptz
FROM brut_weather
ORDER BY year, month, day, hour, origin;

-- 5. Vols : texte → nombres, D942DN → NULL
INSERT INTO flights (year, month, day, dep_time, sched_dep_time, dep_delay, arr_time,
                     sched_arr_time, arr_delay, carrier, flight, tailnum, origin, dest,
                     air_time, distance, hour, minute, time_hour)
SELECT year::int, month::int, day::int, dep_time::int, sched_dep_time::int, dep_delay::int,
       arr_time::int, sched_arr_time::int, arr_delay::int, carrier, flight::int,
       CASE WHEN tailnum ~ '^N[A-Z0-9]{1,5}$' THEN tailnum END,
       origin, dest, air_time::int, distance::int, hour::int, minute::int, time_hour::timestamptz
FROM brut_flights;

-- 6. Suppression des tables brutes
DROP TABLE brut_airlines, brut_airports, brut_planes, brut_weather, brut_flights;

-- 7. Contrôle final
SELECT (SELECT COUNT(*) FROM airlines) AS airlines,
       (SELECT COUNT(*) FROM airports) AS airports,
       (SELECT COUNT(*) FROM planes)   AS planes,
       (SELECT COUNT(*) FROM weather)  AS weather,
       (SELECT COUNT(*) FROM flights)  AS flights;
-- Attendu : 16 | 1462 | 4037 | 26112 | 252704
