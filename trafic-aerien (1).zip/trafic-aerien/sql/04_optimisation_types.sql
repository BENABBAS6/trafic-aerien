-- =====================================================================
-- 04 - Optimisation du stockage : INTEGER → SMALLINT, DOUBLE PRECISION → REAL
-- (valeurs maximales vérifiées avant : toutes tiennent dans ces types)
-- flights : 47 Mo → 36 Mo (-23 %)
-- =====================================================================

-- FLIGHTS : tous les entiers tiennent dans SMALLINT (-32 768 à 32 767), sauf id
ALTER TABLE flights
  ALTER COLUMN year           TYPE SMALLINT,
  ALTER COLUMN month          TYPE SMALLINT,
  ALTER COLUMN day            TYPE SMALLINT,
  ALTER COLUMN dep_time       TYPE SMALLINT,
  ALTER COLUMN sched_dep_time TYPE SMALLINT,
  ALTER COLUMN dep_delay      TYPE SMALLINT,
  ALTER COLUMN arr_time       TYPE SMALLINT,
  ALTER COLUMN sched_arr_time TYPE SMALLINT,
  ALTER COLUMN arr_delay      TYPE SMALLINT,
  ALTER COLUMN flight         TYPE SMALLINT,
  ALTER COLUMN air_time       TYPE SMALLINT,
  ALTER COLUMN distance       TYPE SMALLINT,
  ALTER COLUMN hour           TYPE SMALLINT,
  ALTER COLUMN minute         TYPE SMALLINT;

-- WEATHER : entiers → SMALLINT, décimaux → REAL (4 octets au lieu de 8)
ALTER TABLE weather
  ALTER COLUMN year       TYPE SMALLINT,
  ALTER COLUMN month      TYPE SMALLINT,
  ALTER COLUMN day        TYPE SMALLINT,
  ALTER COLUMN hour       TYPE SMALLINT,
  ALTER COLUMN temp       TYPE REAL,
  ALTER COLUMN dewp       TYPE REAL,
  ALTER COLUMN humid      TYPE REAL,
  ALTER COLUMN wind_dir   TYPE REAL,
  ALTER COLUMN wind_speed TYPE REAL,
  ALTER COLUMN wind_gust  TYPE REAL,
  ALTER COLUMN precip     TYPE REAL,
  ALTER COLUMN pressure   TYPE REAL,
  ALTER COLUMN visib      TYPE REAL;

-- PLANES
ALTER TABLE planes
  ALTER COLUMN year    TYPE SMALLINT,
  ALTER COLUMN engines TYPE SMALLINT,
  ALTER COLUMN seats   TYPE SMALLINT,
  ALTER COLUMN speed   TYPE SMALLINT;

-- AIRPORTS
ALTER TABLE airports
  ALTER COLUMN lat TYPE REAL,
  ALTER COLUMN lon TYPE REAL,
  ALTER COLUMN alt TYPE SMALLINT,
  ALTER COLUMN tz  TYPE SMALLINT;

-- Taille des tables après optimisation
SELECT relname AS table_, pg_size_pretty(pg_total_relation_size(relid)) AS taille
FROM pg_catalog.pg_statio_user_tables ORDER BY pg_total_relation_size(relid) DESC;
