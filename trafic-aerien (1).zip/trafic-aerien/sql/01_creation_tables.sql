-- =====================================================================
-- 01 - Création des tables (PostgreSQL / Supabase)
-- À exécuter dans le SQL Editor de Supabase
-- =====================================================================

DROP TABLE IF EXISTS flights, weather, planes, airlines, airports CASCADE;

-- Compagnies
CREATE TABLE airlines (
  carrier VARCHAR(2) PRIMARY KEY CHECK (carrier ~ '^[A-Z0-9]{2}$'),
  name    TEXT NOT NULL
);

-- Aéroports
CREATE TABLE airports (
  faa   VARCHAR(3) PRIMARY KEY CHECK (faa ~ '^[A-Z0-9]{3}$'),
  name  TEXT NOT NULL,
  lat   DOUBLE PRECISION,
  lon   DOUBLE PRECISION,
  alt   INTEGER,
  tz    INTEGER,
  dst   CHAR(1) CHECK (dst IN ('A', 'N', 'U')),
  tzone TEXT
);

-- Avions
CREATE TABLE planes (
  tailnum      VARCHAR(6) PRIMARY KEY CHECK (tailnum ~ '^N[A-Z0-9]{1,5}$'),
  year         INTEGER,
  type         TEXT,
  manufacturer TEXT,
  model        TEXT,
  engines      INTEGER,
  seats        INTEGER,
  speed        INTEGER,
  engine       TEXT
);

-- Météo
CREATE TABLE weather (
  origin     VARCHAR(3) NOT NULL REFERENCES airports(faa),
  year       INTEGER NOT NULL,
  month      INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  day        INTEGER NOT NULL CHECK (day BETWEEN 1 AND 31),
  hour       INTEGER NOT NULL CHECK (hour BETWEEN 0 AND 23),
  temp       DOUBLE PRECISION,
  dewp       DOUBLE PRECISION,
  humid      DOUBLE PRECISION,
  wind_dir   DOUBLE PRECISION,
  wind_speed DOUBLE PRECISION,
  wind_gust  DOUBLE PRECISION,
  precip     DOUBLE PRECISION,
  pressure   DOUBLE PRECISION,
  visib      DOUBLE PRECISION,
  time_hour  TIMESTAMPTZ,
  PRIMARY KEY (year, month, day, hour, origin)
);

-- Vols
CREATE TABLE flights (
  id             SERIAL PRIMARY KEY,
  year           INTEGER NOT NULL,
  month          INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
  day            INTEGER NOT NULL CHECK (day BETWEEN 1 AND 31),
  dep_time       INTEGER,
  sched_dep_time INTEGER,
  dep_delay      INTEGER,
  arr_time       INTEGER,
  sched_arr_time INTEGER,
  arr_delay      INTEGER,
  carrier        VARCHAR(2) NOT NULL REFERENCES airlines(carrier),
  flight         INTEGER NOT NULL,
  tailnum        VARCHAR(6) REFERENCES planes(tailnum),
  origin         VARCHAR(3) NOT NULL REFERENCES airports(faa),
  dest           VARCHAR(3) NOT NULL REFERENCES airports(faa),
  air_time       INTEGER,
  distance       INTEGER,
  hour           INTEGER NOT NULL,
  minute         INTEGER,
  time_hour      TIMESTAMPTZ,
  UNIQUE (year, month, day, hour, carrier, flight)
);

-- Sécurité : les tables ne sont pas lisibles via l'API publique de Supabase
ALTER TABLE airlines ENABLE ROW LEVEL SECURITY;
ALTER TABLE airports ENABLE ROW LEVEL SECURITY;
ALTER TABLE planes   ENABLE ROW LEVEL SECURITY;
ALTER TABLE weather  ENABLE ROW LEVEL SECURITY;
ALTER TABLE flights  ENABLE ROW LEVEL SECURITY;
