# Problèmes rencontrés et stratégies mises en place

Ce document recense les anomalies trouvées dans les données et les solutions appliquées. Il sert de base au tableau **Trello** (méthode Agile / Scrum) : chaque ligne correspond à une carte.

## 1. Anomalies dans les données

| # | Problème | Table | Détection | Stratégie | Statut |
|---|---|---|---|---|---|
| 1 | Fichier `flights.xlsx` : tout le CSV est dans **une seule colonne** | flights | ouverture du fichier | découpage avec `str.split(",", expand=True)` | ✅ |
| 2 | Valeurs manquantes codées par un **espace `" "`** | flights | `dep_time` non numérique, 0 vol annulé trouvé | remplacement par `NULL` (`replace(" ", None)`) | ✅ |
| 3 | **Fichier incomplet** : vols du 4 juillet au 30 septembre absents | flights | comptage des vols par mois | signalé dans le rendu ; mois incomplets exclus des moyennes | ⚠️ limite |
| 4 | Vols datés **2021** alors que ce sont les vols de **2013** | flights | incohérence des jours de la semaine | calendrier 2013 utilisé pour les jours de la semaine et les jours fériés | ✅ |
| 5 | Colonne d'index inutile `Unnamed: 0` | airports | lecture du fichier | colonne supprimée | ✅ |
| 6 | `tzone = '\N'` : valeur manquante mal codée (3 aéroports) | airports | 10 fuseaux dont un « \N » | `NULLIF(tzone, '\N')` | ✅ |
| 7 | **4 aéroports** (BQN, PSE, SJU, STT) absents de `airports` | flights → airports | requête `NOT IN` (clé étrangère) | ajout des 4 aéroports dans `airports` | ✅ |
| 8 | **716 avions** absents de `planes` (surtout AA et MQ : numéros de flotte) | flights → planes | requête `NOT IN` (clé étrangère) | ajout de leur immatriculation dans `planes` | ✅ |
| 9 | Immatriculation **`D942DN`** hors nomenclature (3 vols) | flights | regex `^N[A-Z0-9]{1,5}$` | mise à `NULL` | ✅ |
| 10 | **3 doublons** dans `weather` (passage à l'heure d'hiver, 3/11 à 1 h) | weather | `GROUP BY ... HAVING COUNT(*) > 1` | une seule ligne gardée (`DISTINCT ON`) | ✅ |
| 11 | `flight` seul **n'est pas une clé primaire** | flights | 3 652 valeurs pour 252 704 vols | clé `id` + `UNIQUE (year, month, day, hour, carrier, flight)` | ✅ |
| 12 | Pas de clé étrangère possible entre `flights` et `weather` (2021 contre 2013) | flights / weather | comparaison des années | jointure sur `origin, month, day, hour` | ⚠️ limite |
| 13 | Heures au format HHMM (`517`), non calculables | flights | énoncé 3.1 et 1.1 | conversion en dates et en minutes depuis minuit | ✅ |
| 14 | Vols partis **après minuit** à cause d'un retard : mauvaise date | flights | 0,3 % de retards incohérents | départ réel = départ prévu + retard | ✅ |
| 15 | `air_time` ≠ `arr_time − dep_time` | flights | comparaison des durées | correction des **fuseaux horaires** (table airports) : il reste ≈ 30 min de roulage au sol | ✅ |
| 16 | Vitesse aberrante (703 mph) | flights | tri par vitesse | signalée comme valeur aberrante | ⚠️ signalé |
| 17 | Destination **HNL** très éloignée (outlier) | flights | distance 2 fois supérieure à la 2e | exclue de l'analyse distance / retard | ✅ |
| 18 | Date de Thanksgiving fausse dans l'énoncé (29/11 au lieu du 28/11/2013) | énoncé | vérification du calendrier | les deux dates sont analysées | ✅ |
| 19 | Tables `airlines`, `planes`, `weather` non fournies | — | — | chargées depuis le paquet officiel `nycflights13` | ✅ |

## 2. Problèmes techniques

| # | Problème | Stratégie | Statut |
|---|---|---|---|
| 20 | Mot de passe visible dans le notebook | mot de passe saisi avec `getpass`, notebook nettoyé | ✅ |
| 21 | Connexion Colab → Supabase impossible en « Direct connection » (IPv6) | utilisation du **Session pooler** | ✅ |
| 22 | Colab efface les fichiers au redémarrage | données lues directement depuis Supabase | ✅ |
| 23 | `SET ROLE` refusé sur Supabase pour tester les droits | vérification avec `has_table_privilege()` | ✅ |
| 24 | Types trop lourds (`int4`, `float8`) | conversion en `SMALLINT` / `REAL` après vérification des valeurs max (−23 %) | ✅ |
| 25 | Application Streamlit à rendre accessible | lancement depuis Colab + tunnel `cloudflared` | ✅ |

## 3. Organisation du Trello (méthode Agile)

**Colonnes :** `Backlog` → `À faire (sprint)` → `En cours` → `En test` → `Terminé`

**Étiquettes :** 🟦 Données · 🟩 Base de données · 🟨 Analyse · 🟪 Application · 🟥 Bloquant

| Sprint | Objectif | Cartes |
|---|---|---|
| Sprint 1 | Explorer les données | Mission 1 (Q1 à Q8), problèmes 1 à 6 |
| Sprint 2 | Construire la base | création des tables, contrôles regex / PK / FK, problèmes 7 à 12, nettoyage, insertion |
| Sprint 3 | Optimiser et sécuriser | types optimisés, privilèges, Row Level Security, SSL |
| Sprint 4 | Reporting | 3.1 à 3.4, 1.1, 1.2, problèmes 13 à 18 |
| Sprint 5 | Application et livrables | application Streamlit, README, GitHub, présentation |
