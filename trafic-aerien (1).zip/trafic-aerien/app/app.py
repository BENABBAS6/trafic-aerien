import pandas as pd
import plotly.express as px
import streamlit as st
from sqlalchemy import URL, create_engine
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OrdinalEncoder

st.set_page_config(page_title="Trafic aérien NYC", page_icon="✈️", layout="wide")

BLEU = "#2a78d6"
SEUIL = 15  # un vol est "en retard" s'il arrive avec plus de 15 minutes de retard (norme BTS)
MOIS = {1: "Jan", 2: "Fév", 3: "Mar", 4: "Avr", 5: "Mai", 6: "Juin",
        7: "Juil", 8: "Août", 9: "Sept", 10: "Oct", 11: "Nov", 12: "Déc"}


# ---------------------------------------------------------------- Connexion sécurisée
@st.cache_resource
def connexion():
    s = st.secrets["supabase"]  # mot de passe stocké dans les "Secrets" de Streamlit, jamais dans le code
    url = URL.create("postgresql+psycopg2", username=s["user"], password=s["password"],
                     host=s["host"], port=int(s["port"]), database=s["database"],
                     query={"sslmode": s.get("sslmode", "require")})  # connexion chiffrée
    return create_engine(url)


# ---------------------------------------------------------------- Données (requête SQL)
@st.cache_data(ttl=3600, show_spinner="Chargement des données depuis la base…")
def charger():
    requete = """
        SELECT f.month, f.day, f.hour, f.carrier, a.name AS compagnie,
               f.origin, f.dest, d.name AS destination,
               f.dep_time, f.dep_delay, f.arr_delay, f.distance,
               w.temp, w.wind_speed, w.precip, w.visib
        FROM flights f
        JOIN airlines a      ON a.carrier = f.carrier
        LEFT JOIN airports d ON d.faa = f.dest
        LEFT JOIN weather w  ON w.origin = f.origin AND w.month = f.month
                            AND w.day = f.day AND w.hour = f.hour
    """
    df = pd.read_sql(requete, connexion())
    df["annule"] = df["dep_time"].isna()
    df["en_retard"] = df["arr_delay"] > SEUIL
    df["compagnie"] = df["compagnie"].str.replace(r"\s+(Inc\.|Co\.|Corporation)$", "", regex=True)
    return df


def taux(serie_bool):
    return 100 * serie_bool.mean() if len(serie_bool) else 0


def barres(df, x, y, titre, label_y, horizontal=False, format_texte=".1f"):
    fig = px.bar(df, x=y if horizontal else x, y=x if horizontal else y,
                 orientation="h" if horizontal else "v", text_auto=format_texte,
                 color_discrete_sequence=[BLEU])
    fig.update_layout(title=titre, xaxis_title=label_y if horizontal else "",
                      yaxis_title="" if horizontal else label_y,
                      margin=dict(l=10, r=10, t=50, b=10), height=420)
    fig.update_traces(textposition="outside", cliponaxis=False)
    return fig


df = charger()

# ---------------------------------------------------------------- Filtres
st.sidebar.header("Filtres")
aeroports = st.sidebar.multiselect("Aéroport de départ", sorted(df["origin"].unique()),
                                   default=sorted(df["origin"].unique()))
compagnies = st.sidebar.multiselect("Compagnies", sorted(df["compagnie"].unique()),
                                    placeholder="Toutes")
mois = st.sidebar.multiselect("Mois", sorted(df["month"].unique()), format_func=MOIS.get,
                              placeholder="Tous")

f = df[df["origin"].isin(aeroports)]
if compagnies:
    f = f[f["compagnie"].isin(compagnies)]
if mois:
    f = f[f["month"].isin(mois)]

st.sidebar.caption(f"Un vol est **en retard** s'il arrive avec plus de {SEUIL} min de retard. "
                   "Un vol est **annulé** s'il n'a pas d'heure de décollage.")
st.sidebar.caption("⚠️ Les données ne contiennent pas les vols du 4 juillet au 30 septembre.")

# ---------------------------------------------------------------- En-tête et indicateurs
st.title("✈️ Retards et annulations au départ de New York")
st.caption("Aide à la décision : identifier quand, où et pourquoi les retards se produisent.")

if f.empty:
    st.warning("Aucun vol ne correspond aux filtres.")
    st.stop()

arrives = f[~f["annule"]]
c1, c2, c3, c4 = st.columns(4)
c1.metric("Vols programmés", f"{len(f):,}".replace(",", " "))
c2.metric("Vols en retard", f"{taux(arrives['en_retard']):.1f} %")
c3.metric("Vols annulés", f"{taux(f['annule']):.1f} %")
c4.metric("Retard moyen à l'arrivée", f"{arrives['arr_delay'].mean():.1f} min")

onglets = st.tabs(["📅 Quand ?", "🏢 Qui ?", "📍 Où ?", "🌧️ Météo", "🔮 Prédiction"])

# ---------------------------------------------------------------- 1. Quand ?
with onglets[0]:
    g1, g2 = st.columns(2)
    par_heure = (arrives.groupby("hour")["en_retard"].mean().mul(100).reset_index())
    fig = px.line(par_heure, x="hour", y="en_retard", markers=True, color_discrete_sequence=[BLEU])
    fig.update_layout(title="% de vols en retard selon l'heure de départ prévue",
                      xaxis_title="Heure", yaxis_title="% en retard", height=420,
                      margin=dict(l=10, r=10, t=50, b=10))
    g1.plotly_chart(fig, width="stretch")

    par_mois = arrives.groupby("month")["en_retard"].mean().mul(100).reset_index()
    par_mois["mois"] = par_mois["month"].map(MOIS).replace({"Juil": "Juil*"})
    g2.plotly_chart(barres(par_mois, "mois", "en_retard", "% de vols en retard par mois", "% en retard"),
                    width="stretch")
    if 7 in par_mois["month"].values:
        g2.caption("* Juillet : seulement les 3 premiers jours sont dans les données.")

    pire_h = par_heure.loc[par_heure["en_retard"].idxmax()]
    meilleure_h = par_heure.loc[par_heure["en_retard"].idxmin()]
    st.info(f"**À retenir :** les retards s'accumulent au fil de la journée. "
            f"À {int(meilleure_h['hour'])} h, {meilleure_h['en_retard']:.0f} % des vols sont en retard ; "
            f"à {int(pire_h['hour'])} h, {pire_h['en_retard']:.0f} %. "
            "Les vols du matin sont les plus fiables.")

# ---------------------------------------------------------------- 2. Qui ?
with onglets[1]:
    g1, g2 = st.columns(2)
    comp = (f.groupby("compagnie")
             .agg(vols=("annule", "size"), annules=("annule", "mean"))
             .join(arrives.groupby("compagnie")["en_retard"].mean()))
    comp = comp[comp["vols"] >= 100]
    comp["en_retard"] *= 100
    comp["annules"] *= 100
    comp = comp.reset_index()

    g1.plotly_chart(barres(comp.sort_values("en_retard"), "compagnie", "en_retard",
                           "% de vols en retard par compagnie", "% en retard", horizontal=True),
                    width="stretch")
    g2.plotly_chart(barres(comp.sort_values("annules"), "compagnie", "annules",
                           "% de vols annulés par compagnie", "% annulés", horizontal=True),
                    width="stretch")
    pire = comp.loc[comp["en_retard"].idxmax()]
    st.info(f"**À retenir :** {pire['compagnie']} a le plus fort taux de retard "
            f"({pire['en_retard']:.0f} % de ses vols). Compagnies de moins de 100 vols non affichées.")

# ---------------------------------------------------------------- 3. Où ?
with onglets[2]:
    g1, g2 = st.columns(2)
    orig = arrives.groupby("origin")["en_retard"].mean().mul(100).reset_index()
    g1.plotly_chart(barres(orig, "origin", "en_retard", "% de vols en retard par aéroport de départ",
                           "% en retard"), width="stretch")

    dest = (arrives.groupby("destination")
                   .agg(vols=("en_retard", "size"), en_retard=("en_retard", "mean"))
                   .query("vols >= 500"))
    dest["en_retard"] *= 100
    top = dest.sort_values("en_retard").tail(10).reset_index()
    g2.plotly_chart(barres(top, "destination", "en_retard",
                           "Les 10 destinations les plus touchées (≥ 500 vols)", "% en retard",
                           horizontal=True), width="stretch")

# ---------------------------------------------------------------- 4. Météo
with onglets[3]:
    st.caption("Météo relevée à l'aéroport de départ, à l'heure prévue du vol.")
    m = arrives.dropna(subset=["precip", "visib", "wind_speed"]).copy()
    m["Pluie"] = pd.cut(m["precip"], [-1, 0, 0.1, 100], labels=["Aucune", "Faible", "Forte"])
    m["Visibilité"] = pd.cut(m["visib"], [-1, 2, 5, 9.9, 100],
                             labels=["< 2 miles", "2–5 miles", "5–10 miles", "Parfaite"])
    m["Vent"] = pd.cut(m["wind_speed"], [-1, 10, 20, 1000],
                       labels=["< 10 mph", "10–20 mph", "> 20 mph"])
    cols = st.columns(3)
    for col, var in zip(cols, ["Pluie", "Visibilité", "Vent"]):
        t = m.groupby(var, observed=True)["en_retard"].mean().mul(100).reset_index()
        col.plotly_chart(barres(t, var, "en_retard", f"% en retard selon : {var.lower()}", "% en retard"),
                         width="stretch")
    st.info("**À retenir :** la pluie et la mauvaise visibilité multiplient le risque de retard. "
            "Les jours annoncés pluvieux ou brumeux, il faut prévoir plus de personnel.")

# ---------------------------------------------------------------- 5. Prédiction
VARIABLES = ["carrier", "origin", "month", "hour", "distance", "precip", "visib", "wind_speed"]


@st.cache_resource(show_spinner="Entraînement du modèle de prédiction…")
def entrainer(donnees):
    d = donnees[~donnees["annule"]].dropna(subset=VARIABLES + ["arr_delay"])
    X, y = d[VARIABLES], d["en_retard"]
    # carrier et origin sont du texte : on les transforme en nombres, le reste passe tel quel
    prep = ColumnTransformer([("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1),
                               ["carrier", "origin"])], remainder="passthrough")
    modele = make_pipeline(prep, HistGradientBoostingClassifier(categorical_features=[0, 1],
                                                                max_iter=200, random_state=0))
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)
    modele.fit(X_train, y_train)
    auc = roc_auc_score(y_test, modele.predict_proba(X_test)[:, 1])
    return modele, auc, y.mean()


with onglets[4]:
    modele, auc, moyenne = entrainer(df)
    st.write("Estimez le **risque qu'un vol arrive avec plus de 15 minutes de retard**.")
    noms = df.drop_duplicates("carrier").set_index("carrier")["compagnie"].sort_values()
    c1, c2, c3 = st.columns(3)
    p_comp = c1.selectbox("Compagnie", noms.index, format_func=noms.get, index=list(noms.index).index("UA"))
    p_orig = c1.selectbox("Aéroport de départ", ["EWR", "JFK", "LGA"])
    p_mois = c2.selectbox("Mois", list(MOIS), format_func=MOIS.get, index=11)
    p_heure = c2.slider("Heure de départ prévue", 5, 23, 18)
    p_dist = c2.slider("Distance (miles)", 100, 3000, 1000, step=50)
    p_pluie = c3.select_slider("Pluie (pouces/heure)", [0.0, 0.02, 0.05, 0.1, 0.2, 0.5], value=0.0)
    p_visib = c3.slider("Visibilité (miles)", 0.0, 10.0, 10.0, step=0.5)
    p_vent = c3.slider("Vent (mph)", 0, 40, 10)

    entree = pd.DataFrame([{"carrier": p_comp, "origin": p_orig, "month": p_mois, "hour": p_heure,
                            "distance": p_dist, "precip": p_pluie, "visib": p_visib,
                            "wind_speed": p_vent}])
    risque = 100 * modele.predict_proba(entree)[0, 1]
    niveau = "🟢 Faible" if risque < 15 else "🟠 Modéré" if risque < 30 else "🔴 Élevé"
    st.metric("Risque de retard estimé", f"{risque:.0f} %",
              delta=f"{risque - 100 * moyenne:+.0f} pts par rapport à la moyenne ({100 * moyenne:.0f} %)",
              delta_color="inverse")
    st.write(f"Niveau de risque : **{niveau}**")
    st.caption(f"Modèle : gradient boosting entraîné sur 80 % des vols de la base, testé sur les 20 % restants. "
               f"Qualité (AUC) : {auc:.2f} (0,5 = hasard, 1 = parfait). "
               "C'est une estimation statistique, pas une certitude.")
